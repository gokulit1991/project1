package com.Myfirst.dao;

import com.Myfirst.model.Customer;

public interface CustomerDao {
void registerCustomer(Customer customer);
}
