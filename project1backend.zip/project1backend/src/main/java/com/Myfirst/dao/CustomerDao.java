package com.Myfirst.dao;



import com.Myfirst.model.Customer;

import com.Myfirst.model.User;



public interface CustomerDao {

void registerCustomer(Customer customer);



}

