package com.Myfirst.dao;



import com.Myfirst.model.CartItem;

import com.Myfirst.model.CustomerOrder;

import com.Myfirst.model.User;



public interface CartItemDao {

	void saveOrUpdateCartItem(CartItem cartItem);

	void removeCartItem(int cartItemId);

    User getUser(String email);

	CustomerOrder createOrder(User user);

}

