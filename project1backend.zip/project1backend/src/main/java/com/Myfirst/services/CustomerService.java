package com.Myfirst.services;



import com.Myfirst.model.Customer;

import com.Myfirst.model.User;



public interface CustomerService {

void registerCustomer(Customer customer);



}



