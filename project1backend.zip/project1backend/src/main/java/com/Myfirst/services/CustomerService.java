package com.Myfirst.services;

import com.Myfirst.model.Customer;

public interface CustomerService {
void registerCustomer(Customer customer);
}
