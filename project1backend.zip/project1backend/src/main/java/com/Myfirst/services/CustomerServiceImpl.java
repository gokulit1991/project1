package com.Myfirst.services;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



import com.Myfirst.dao.CustomerDao;

import com.Myfirst.model.Customer;

import com.Myfirst.model.User;

@Service

public class CustomerServiceImpl implements CustomerService {

	@Autowired

private CustomerDao customerDao;

	public void registerCustomer(Customer customer) {

		customerDao.registerCustomer(customer);

	}

	

}

