package com.Myfirst.project1backend;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Myfirst.configuration.DBConfiguration;
import com.Myfirst.dao.ProductDao;
import com.Myfirst.model.Category;
import com.Myfirst.model.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
		ApplicationContext ctx= new AnnotationConfigApplicationContext(DBConfiguration.class);
        ProductDao productDao=ctx.getBean(ProductDao.class);
        Category c = new Category();
        c.setCategoryname("Mobile");
        Product p= new Product();
        p.setProductname("Mobile");
        p.setProductdescription("samgung");
        p.setPrice(10000);
        productDao.saveOrUpdateProduct(p);
        System.out.println("Hello World");
        
    }
}
